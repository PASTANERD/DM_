#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 64
#define MAX_SIZE_ROOT 8
#define MAX_LENGTH 100
void LoadData(char* argument, int* data);
void ConstructSolution(int* data);
void ConvertData(int* solution);
void Z3Solver();
void TestPrint(int* data);
void TestOutput(int *solution);

int main(int argc, char* argv[]){
  int* data;
  int* solution;

  data = malloc(sizeof(int)*MAX_SIZE+1);
  solution = malloc(sizeof(int)*MAX_SIZE+1);
  
  data[MAX_SIZE+1] = 0;
  solution[MAX_SIZE+1] = 0;

  printf("Loading Input data. \n");
  LoadData(argv[1], data);
  printf("Test Print for input data --- \n");
  //TestPrint(data);
  TestOutput(data);
  printf("\n");
  
  printf("Generating Formula. \n");
  ConstructSolution(data);

  printf("Running Z3 Solver\n");
  Z3Solver();

  printf("Extracting Result to output file\n");
  ConvertData(solution);
  printf("Test Print for solution data --- \n");
  //TestPrint(solution);
  TestOutput(solution);
  printf("\n");
}


void LoadData(char* argument, int* data){
  FILE* stream_input;
  char* box;

  box = malloc(sizeof(char)*2);
  
  if((stream_input = fopen(argument, "r")) != NULL){
    for(int i = 0; i < MAX_SIZE ; i++){
      fscanf(stream_input, "%s", box);
      if(!strcmp(box, "?") || !strcmp(box, "0")){
        data[i] = 0;
      }
      else if(!strcmp(box, "O")){
        data[i] = 1;
      }
      else if(!strcmp(box, "X")){
        data[i] = 2;
      }
      else continue;
    }
  }
  else{
    perror("Error: input FILE");
  }

  free(box);
  fclose(stream_input);
}

void ConstructSolution(int* from_input){
  /*TODO * z3를 이용하여 fomular.txt를 생성하는 기능을 담당하는 모듈 */
  
  FILE *stream_result;

  if((stream_result = fopen("formula_3.txt", "w")) == NULL){
    perror("Error: Result file open failed");
  }

  int x, y ; // x : row, y: column
  //int from_input[MAX_SIZE];
  int index = 0;

  //Generating 8 X 8 grid
  for (y = 1 ; y <= 8 ; y++)
    for (x = 1 ; x <= 8 ; x++)
     fprintf(stream_result, "(declare-const a%d%d Int)\n", y, x) ;

  //Assigning values[0 or 1 for ?(denoted by 0), 1 for O(denoted by 1), 2 for X(denoted by 2)]
  for (y = 1 ; y <= 8 ; y++)
    for (x = 1 ; x <= 8 ; x++){
      int mark = from_input[index++];

      if(mark == 0) fprintf(stream_result, "(assert (and (<= a%d%d 1) (<= 0 a%d%d)))\n", y, x, y, x) ;
      //if(mark == 1) fprintf(stream_result, "(assert (= a%d%d 1))\n", y, x, y, x) ;
      if(mark == 1) fprintf(stream_result, "(assert (= a%d%d 1))\n", y, x) ;
      //if(mark == 2) fprintf(stream_result, "(assert (= a%d%d 0))\n", y, x, y, x) ;
      if(mark == 2) fprintf(stream_result, "(assert (= a%d%d 0))\n", y, x) ;
    }


  /*//Formula that assigns 0 or 1 so that can distinguish 'O' and 'X' (1 means 'O', 0 means 'X')
  for (y = 1 ; y <= 8 ; y++)
    for (x = 1 ; x <= 8 ; x++)
      printf("(assert (and (<= a%d%d 1) (<= 0 a%d%d)))\n", y, x, y, x) ;*/

  //Fomula that makes # of O and # of X same for each row
  for (x = 1 ; x <= 8 ; x++){
    fprintf(stream_result, "(assert(= (+ ") ;
      for (y = 1 ; y <= 8 ; y++)
      fprintf(stream_result, "a%d%d ", y, x) ;
    fprintf(stream_result, ") 4))\n") ;
  }

  //Fomula that makes # of O and # of X same for each column
  for (y = 1 ; y <= 8 ; y++){
    fprintf(stream_result, "(assert(= (+ ") ;
      for (x = 1 ; x <= 8 ; x++)
      fprintf(stream_result, "a%d%d ", y, x) ;
      fprintf(stream_result, ") 4))\n") ;
  }

  //Formula that removes cases that have three consecutive 'O' or 'X' in a row
  for(y = 1; y <= 6;y ++){
    for (x = 1 ; x <= 8 ; x++){
      fprintf(stream_result, "(assert (and (< (+ ");
        for (int i = 0 ; i < 3 ; i++){
          fprintf(stream_result, "a%d%d ", y + i, x) ;
        }
      fprintf(stream_result, ") 3) ") ;
      fprintf(stream_result, "(> (+ ");
        for (int i = 0 ; i < 3 ; i++){
            fprintf(stream_result, "a%d%d ", y + i, x) ;
          }
      fprintf(stream_result, ") 0)))\n") ;
    }
  }


  //Formula that removes cases that have three consecutive 'O' or 'X' in a column
  for(x = 1; x <= 6;x ++){
    for (y = 1 ; y <= 8 ; y++){
      fprintf(stream_result, "(assert (and (< (+ ");
        for (int i = 0 ; i < 3 ; i++){
          fprintf(stream_result, "a%d%d ", y , x + i) ;
        }
      fprintf(stream_result, ") 3) ") ;
      fprintf(stream_result, "(> (+ ");
        for (int i = 0 ; i < 3 ; i++){
            fprintf(stream_result, "a%d%d ", y , x + i) ;
          }
      fprintf(stream_result, ") 0)))\n") ;
    }
  }
  fprintf(stream_result, "(check-sat)\n(get-model)\n") ;

  fclose(stream_result);
}

void Z3Solver(){
  system("z3 formula_3.txt >> result_3.txt");
}

void ConvertData(int* solution){

  FILE* stream_formula;
  char *line, *result;
  char temp[3];

  int index, value;
  line = malloc(sizeof(char)*MAX_LENGTH);
  
  if((stream_formula = fopen("result_3.txt", "r")) != NULL){
    if((result = fgets(line, MAX_LENGTH, stream_formula)) != NULL){
      if(!strncmp(result, "unsat", 5)){
        printf("This game is unsatisfiable.");
      }
      else{
        result = fgets(line, MAX_LENGTH, stream_formula);
        do{
          // get index
          if((result = fgets(line, MAX_LENGTH, stream_formula)) != NULL){
            memcpy(temp, &result[15], 2);
            temp[2] = 0;
            index = atoi(temp) - 11;
          }
          //get value
          if((result = fgets(line, MAX_LENGTH, stream_formula)) != NULL){
            memcpy(temp, &result[4], 1);
            temp[1] = 0;
            value = atoi(temp);
          }
          solution[index] = value;
        }while(!feof(stream_formula));
        
      }
    }
  }
  else{
    perror("Error: result.txt opne failed");
  }

  free(line);
  fclose(stream_formula);
}

void TestPrint(int* data){
  for(int i = 0 ; i < MAX_SIZE ; i++ ){
     printf("%d) %d\n", i, data[i]);
  }
}

void TestOutput(int *solution){
  for(int i = 0; i < MAX_SIZE ; i++){
    printf("%d ", solution[i]);
    if(i%MAX_SIZE_ROOT == MAX_SIZE_ROOT - 1) printf("\n");
  }
}
